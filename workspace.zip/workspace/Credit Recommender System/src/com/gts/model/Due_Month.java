package com.gts.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "due_date")
public class Due_Month {
	@Id
	private int id;
	private String username;
	private String duration;
	private String types;
	private String month1;
	private String amount1;
	private String month2;
	private String amount2;
	private String month3;
	private String amount3;
	private String month4;
	private String amount4;
	private String month5;
	private String amount5;
	private String month6;
	private String amount6;
	private String month7;
	private String amount7;
	private String month8;
	private String amount8;
	private String month9;
	private String amount9;
	private String month10;
	private String amount10;
	private String month11;
	private String amount11;
	private String month12;
	private String amount12;
	private String total_amount;
	
	public String getTotal_amount() {
		return total_amount;
	}
	public void setTotal_amount(String total_amount) {
		this.total_amount = total_amount;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getDuration() {
		return duration;
	}
	public void setDuration(String duration) {
		this.duration = duration;
	}
	public String getTypes() {
		return types;
	}
	public void setTypes(String types) {
		this.types = types;
	}
	public String getMonth1() {
		return month1;
	}
	public void setMonth1(String month1) {
		this.month1 = month1;
	}
	public String getAmount1() {
		return amount1;
	}
	public void setAmount1(String amount1) {
		this.amount1 = amount1;
	}
	public String getMonth2() {
		return month2;
	}
	public void setMonth2(String month2) {
		this.month2 = month2;
	}
	public String getAmount2() {
		return amount2;
	}
	public void setAmount2(String amount2) {
		this.amount2 = amount2;
	}
	public String getMonth3() {
		return month3;
	}
	public void setMonth3(String month3) {
		this.month3 = month3;
	}
	public String getAmount3() {
		return amount3;
	}
	public void setAmount3(String amount3) {
		this.amount3 = amount3;
	}
	public String getMonth4() {
		return month4;
	}
	public void setMonth4(String month4) {
		this.month4 = month4;
	}
	public String getAmount4() {
		return amount4;
	}
	public void setAmount4(String amount4) {
		this.amount4 = amount4;
	}
	public String getMonth5() {
		return month5;
	}
	public void setMonth5(String month5) {
		this.month5 = month5;
	}
	public String getAmount5() {
		return amount5;
	}
	public void setAmount5(String amount5) {
		this.amount5 = amount5;
	}
	public String getMonth6() {
		return month6;
	}
	public void setMonth6(String month6) {
		this.month6 = month6;
	}
	public String getAmount6() {
		return amount6;
	}
	public void setAmount6(String amount6) {
		this.amount6 = amount6;
	}
	public String getMonth7() {
		return month7;
	}
	public void setMonth7(String month7) {
		this.month7 = month7;
	}
	public String getAmount7() {
		return amount7;
	}
	public void setAmount7(String amount7) {
		this.amount7 = amount7;
	}
	public String getMonth8() {
		return month8;
	}
	public void setMonth8(String month8) {
		this.month8 = month8;
	}
	public String getAmount8() {
		return amount8;
	}
	public void setAmount8(String amount8) {
		this.amount8 = amount8;
	}
	public String getMonth9() {
		return month9;
	}
	public void setMonth9(String month9) {
		this.month9 = month9;
	}
	public String getAmount9() {
		return amount9;
	}
	public void setAmount9(String amount9) {
		this.amount9 = amount9;
	}
	public String getMonth10() {
		return month10;
	}
	public void setMonth10(String month10) {
		this.month10 = month10;
	}
	public String getAmount10() {
		return amount10;
	}
	public void setAmount10(String amount10) {
		this.amount10 = amount10;
	}
	public String getMonth11() {
		return month11;
	}
	public void setMonth11(String month11) {
		this.month11 = month11;
	}
	public String getAmount11() {
		return amount11;
	}
	public void setAmount11(String amount11) {
		this.amount11 = amount11;
	}
	public String getMonth12() {
		return month12;
	}
	public void setMonth12(String month12) {
		this.month12 = month12;
	}
	public String getAmount12() {
		return amount12;
	}
	public void setAmount12(String amount12) {
		this.amount12 = amount12;
	}
	

}
